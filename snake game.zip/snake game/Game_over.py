from turtle import Turtle


class GameOver(Turtle):

    def __init__(self):
        super().__init__()

    def over(self):
        self.color("white")
        self.write("game over", move=False, align="center", font=("Arial", 40, "italic"))
